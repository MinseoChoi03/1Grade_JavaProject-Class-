package Test_1;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class WindowHandler extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
    	System.exit(0);
    }
}