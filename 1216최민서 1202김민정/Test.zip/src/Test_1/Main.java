package Test_1;

public class Main {
	
	public static final int SCREEN_WIDTH = 960;
	public static final int SCREEN_HEIGHT = 600;
	
	public static void main(String[] args) {
		
		new Test_test();

	}
}
