package Test_1;
public class Word {
    String date;
    String contents;
    String income;
    String outlay;
    String valance;
   
public Word(String date, String contents, String income, String outlay, String valance) {
this.date = date;
this.contents = contents;
this.income = income;
this.outlay = outlay;
this.valance = valance;
}
public String getDate() {
return date;
}
public void setDate(String date) {
this.date = date;
}
public String getContents() {
return contents;
}
public void setContents(String contents) {
this.contents = contents;
}
public String getIncome() {
return income;
}
public void setIncome(String income) {
this.income = income;
}
public String getOutlay() {
return outlay;
}
public void setOutlay(String outlay) {
this.outlay = outlay;
}
public String getValance() {
return valance;
}
public void setValance(String valance) {
this.valance = valance;
}
   
}